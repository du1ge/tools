import requests
import sys
import threading
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

def get_target(target_file):
    try:
        with open(target_file, "r", encoding='utf-8') as f:
            content = f.read().splitlines()
        return content
    except Exception as e:
        print("\nCan not find the file!\n")
        sys.exit(0)

def test_host(domain):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
    }
    try:
        domain1 = 'http://' + domain
        r1 = requests.get(domain1, headers = headers, timeout = 5, allow_redirects = False)
        if r1.status_code == 200:
            print(domain1)
            intersting.append(domain1)
        
        else:
            domain1 = 'https://' + domain
            r1 = requests.get(domain1, headers = headers, timeout = 5, verify = False, allow_redirects = False)
            if r1.status_code == 200:
                print(domain1)
                intersting.append(domain1)
    except Exception as e:
        #print(e)
        pass

def go_threading(domain_list):
    global intersting
    intersting = []
    threads = []
    for domain in domain_list:
        t = threading.Thread(target=test_host, args=(domain,))
        threads.append(t)
    for i in range(len(threads)):
        threads[i].start()
    for i in range(len(threads)):
        threads[i].join()

def save_target(intersting, filename):
    symbol = '\n'
    f = open(filename, "w", encoding='utf-8')
    f.write(symbol.join(intersting))
    f.close()
    print('\nSave file successfully!\n')

def main():
    target_domain = input('\nPlease input the domain list:')
    domain_list = get_target(target_domain)
    go_threading(domain_list)
    save_target(intersting, 'result.txt')

if __name__ == '__main__':
    print('\n')
    main()
