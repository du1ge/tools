import requests
import sys
import threading

def get_target(target_file):
    try:
        with open(target_file, "r", encoding='utf-8') as f:
            content = f.read().splitlines()
        return content
    except Exception as e:
        print("\nCan not find the file!\n")
        sys.exit(0)

def test_host(ip, domain):
    try:
        headers = {
            'Host': domain
        }
        ip1 = 'http://' + ip
        r1 = requests.get(ip1, timeout = 10)
        #print(r1.status_code)
        if r1.status_code != 404 and r1.status_code == 200:
            r = requests.get(ip1, headers = headers, timeout = 5)
            #print(str(r.status_code))
            #if r.status_code == 200:
            print(domain.ljust(35,' ') + ip.ljust(20, ' ') +  str(r.status_code))
    except Exception as e:
        #print(e)
        pass

def go_threading(ip_list, domain_list):
    threads = []
    for ip in ip_list:
        for domain in domain_list:
            t = threading.Thread(target=test_host, args=(ip, domain))
            threads.append(t)
    for i in range(len(threads)):
        threads[i].start()
    for i in range(len(threads)):
        threads[i].join()


def main():
    ip = input('Please input the ip file:')
    print('\n')
    ip_list = get_target(ip)
    domain = input('Please input the domain file:')
    print('\n')
    domain_list = get_target(domain)
    go_threading(ip_list, domain_list)

if __name__ == '__main__':
    print('\nTesting......\n')
    main()